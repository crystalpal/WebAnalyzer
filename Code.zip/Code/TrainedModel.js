

function TrainedModel() {
    this.mapUrlWithNode = {}; // Map<UrlString, NodeId>
    this.mapNodeWithUrl = {}; // Map<NodeId, UrlString>

    this.mapIdToGraph = {}; // Map<GraphId, TrainedConnectedGraph>

    this.mapNodeToGraph = {}; // Map<NodeId, GraphId>
    this.mapGraphToNodes = {}; // Map<GraphId, Set<NodeId>>

    this.nextNodeId = 1;
    this.nextGraphId = 1;
}


TrainedModel.prototype.selectBestMatches = function(url, maxQuantity) {
    var urlVariants = this.urlToVariants(url);

    var results = [];
    for (var i = 0; i < urlVariants.length; i++) {
        var node = this.mapUrlWithNode[urlVariants[i]];
        if (!node) continue; // variant not available.

        var resultsOfNode = this.selectMatchesOfNode(node);
        results = results.concat(resultsOfNode);
    }

    results.sort(function(a, b) {
        return b[1] - a[1];
    });

    results = results.splice(1, maxQuantity);
    var mapNodeUrl = this.mapNodeWithUrl;
    var urls = results.map(function(pairArr) { return mapNodeUrl[pairArr[0]];});
    return urls;
};


TrainedModel.prototype.selectMatchesOfNode = function(node) {
    var graphId = this.mapNodeToGraph[node];
    var graph = this.mapIdToGraph[graphId];

    var targetsWithWeight = graph.costsFrom(node);

    return targetsWithWeight;
};

TrainedModel.prototype.urlToVariants = function(url) {
    var splitProtocol = url.split("//");
    var actualUrl = splitProtocol[splitProtocol.length - 1]; // last
    var prefix = url.replace(actualUrl, "");

    var segments = actualUrl.split("/");

    if (segments < 2) return [url];

    var variants = [url];

    var lastVariant = prefix + segments[0];
    for (var i = 1; i < segments.length; i++) {
        variants.push(lastVariant +"/*");
        lastVariant+=segments[i];
    }

    return variants;

};

TrainedModel.prototype.train = function(stream) {
    if (stream.length < 2) return;

    console.log("train stream: ");
    console.log(stream);

    var firstUrl = stream[0].url;

    var streamGraphId = null;
    // Ensure that first is added to the mapUrlWithNode.
    var parentNodeId =this.mapUrlWithNode[firstUrl];
    if (!parentNodeId) {
        // Set the reference between url and nodeId
        parentNodeId = this.createNewNodeId(firstUrl);

        // Set the reference between node and graph.
        var graphId = this.createNewGraphId(new TrainedConnectedGraph());
        streamGraphId = graphId;
        this.setReferenceBetweenGraphAndNode(graphId, parentNodeId);
    }
    else {
        streamGraphId = this.mapNodeToGraph[parentNodeId];
        if (!streamGraphId)
            throw "Every node registered in the model must belong to a graph. NodeId: " + parentNodeId;
    }

    if (!streamGraphId)
        throw "Node must be added to graphs, but the graphId is null.";

    // Learn the stream.
    for (var i = 1; i < stream.length; i++) {
        var nextUrl = stream[i].url;
        var nodeId = this.mapUrlWithNode[nextUrl];
        if (!nodeId){
            // Set the reference between url and nodeId
            nodeId = this.createNewNodeId(nextUrl);

            // Set the reference between node and graph.
            this.setReferenceBetweenGraphAndNode(streamGraphId, nodeId);
        }
        else streamGraphId = this.enforceSameGraphBetween(parentNodeId, nodeId);

        var graph = this.mapIdToGraph[streamGraphId];
        if (!graph)
            throw "A node cannot be linked to a non-existing graph for nodeId = " + nodeId + " and graphId = " + graphId;
        graph.addOrFeedLinkBetween(parentNodeId, nodeId);

        parentNodeId = nodeId;
    }


    var graph = this.mapIdToGraph[streamGraphId];
    graph.evaporate();
    var removedNodes = [];
    var newGraphs = graph.splitGraphsOnNegativeLinks(removedNodes);
    for (var i = 0; i < removedNodes.length; i++) {
        this.removeNode(removedNodes[i]);
    }

    // Ensure that the references between node and graphId are correct.
    if(newGraphs && newGraphs.length > 0) {
        for (var i = 0 ; i < newGraphs.length; i++) {
            var newGraph = newGraphs[i];
            var newGraphId = this.createNewGraphId(newGraph);
            var nodesOfNewGraph = newGraph.getNodes();
            for (var node in nodesOfNewGraph) {
                this.removeReferenceBetweenGraphAndNode(streamGraphId, node);
                this.setReferenceBetweenGraphAndNode(newGraphId, node);
            }
        }
    }
};

/*
 * If graph of nodeA and nodeB is different, remove the smallest and move all nodes and links to the largest.
 * Returns the resulting graphId.
 */
TrainedModel.prototype.enforceSameGraphBetween = function(nodeA, nodeB) {
    if (!nodeA || !nodeB) throw "nodeA and nodeB cannot be null.";

    var graphIdA = this.mapNodeToGraph[nodeA];
    var graphIdB = this.mapNodeToGraph[nodeB];
    if (!graphIdA || !graphIdB)
        throw "nodeA or nodeB is not part of a graph in mapNodeToGraph"
    if (graphIdA === graphIdB) return graphIdA;

    var nodesInGraphA = this.mapGraphToNodes[graphIdA];
    var nodesInGraphB = this.mapGraphToNodes[graphIdB];

    var keysA = Object.keys(nodesInGraphA);
    var keysB = Object.keys(nodesInGraphB);

    var graphA = this.mapIdToGraph[graphIdA];
    var graphB = this.mapIdToGraph[graphIdB];

    if (keysA.length < keysB.length) {
        graphB.extractLinksFrom(graphA);
        this.mergeGraphInto(graphIdA, graphIdB);
        return graphIdB;
    }
    else {
        graphA.extractLinksFrom(graphB);
        this.mergeGraphInto(graphIdB, graphIdA);
        return graphIdA;
    }
}

TrainedModel.prototype.mergeGraphInto = function(graphIdA, graphIdB) {
    var nodesOfA = Object.keys(this.mapGraphToNodes[graphIdA]);
    var nodeSetOfB = this.mapGraphToNodes[graphIdB];


    // Remove the graph
    delete this.mapIdToGraph[graphIdA];

    // Detach nodes from the graphA
    delete this.mapGraphToNodes[graphIdA];
    for(var i = 0; i < nodesOfA.length; i++) {
        var node = nodesOfA[i];
        this.mapNodeToGraph[node] = graphIdB; // overwrite this.mapNodeToGraph[someNodeOfA] = graphIdA to graphIdB
        nodeSetOfB[node] = true; // attach the node of A to this.mapGraphToNodes[graphIdB]
    }
}

TrainedModel.prototype.createNewGraphId = function(graph) {
    var graphId = this.nextGraphId++;
    this.mapIdToGraph[graphId] = graph;

    return graphId;
};

TrainedModel.prototype.createNewNodeId = function(url) {
    var parentNodeId = this.nextNodeId++;
    this.mapUrlWithNode[url] = parentNodeId;
    this.mapNodeWithUrl[parentNodeId] = url;

    return parentNodeId;
};

TrainedModel.prototype.removeNode = function(nodeId) {
    var url = this.mapNodeWithUrl[nodeId];
    delete this.mapUrlWithNode[url];
    delete this.mapNodeWithUrl[nodeId];
};

TrainedModel.prototype.setReferenceBetweenGraphAndNode = function(graphId, nodeId) {
    this.mapNodeToGraph[nodeId] = graphId;
    if (!this.mapGraphToNodes[graphId])
        this.mapGraphToNodes[graphId] = {};
    this.mapGraphToNodes[graphId][nodeId] = true;
};

TrainedModel.prototype.removeReferenceBetweenGraphAndNode = function(graphId, nodeId) {
    delete this.mapNodeToGraph[nodeId];
    delete this.mapGraphToNodes[graphId][nodeId];

    if (Object.keys(this.mapGraphToNodes[graphId]).length <=0)
        delete this.mapGraphToNodes[graphId];
};

TrainedModel.prototype.trainFromActivityStreams = function(streams) {
    for(var i = 0; i < streams.length; i++) {
        this.train(streams[i]);
    }
};

TrainedModel.deserialize = function(data) {

    var mapIdToGraph = {}; // Map<GraphId, TrainedConnectedGraph>
    for (var graphId in data.mapIdToGraph) {
        var graphData = data.mapIdToGraph[graphId];
        var graph = TrainedConnectedGraph.deserialize(graphData);
        mapIdToGraph[graphId] = graph;
    }

    var mapUrlWithNode = {};
    for(var node in data.mapNodeWithUrl) {
        var url = data.mapNodeWithUrl[node];
        mapUrlWithNode[url] = node;
    }

    var mapNodeToGraph = {};
    for(var graphId in data.mapGraphToNodes) {
        var nodesSet = data.mapGraphToNodes[graphId];
        var nodes = Object.keys(nodesSet);
        for(var j = 0; j < nodes.length; j++) {
            var node = nodes[j];
            mapNodeToGraph[node] = graphId;
        }
    }

    var tm = new TrainedModel();
    tm.mapNodeWithUrl = data.mapNodeWithUrl;
    tm.mapUrlWithNode = mapUrlWithNode;

    tm.mapGraphToNodes = data.mapGraphToNodes;
    tm.mapNodeToGraph = mapNodeToGraph;

    tm.mapIdToGraph = mapIdToGraph;

    tm.nextGraphId = data.nextGraphId;
    tm.nextNodeId = data.nextNodeId;



    return tm;
};

TrainedModel.prototype.serialize = function() {
    var data = {};

    data.mapNodeWithUrl = this.mapNodeWithUrl;
    data.mapGraphToNodes = this.mapGraphToNodes;
    data.mapIdToGraph = {};
    var graphIds = Object.keys(this.mapIdToGraph);
    for(var i = 0; i < graphIds.length; i++) {
        var graphId = graphIds[i];
        var graph = this.mapIdToGraph[graphId]
        var graphSerialized = graph.serialize();
        data.mapIdToGraph[graphId] = graphSerialized;
    }
    data.nextGraphId = this.nextGraphId;
    data.nextNodeId = this.nextNodeId;

    return data;
};

TrainedModel.prototype.getNodeArray = function() {
    var result = [];

    var nodes = Object.keys(this.mapNodeWithUrl);

    for (var i = 0; i < nodes.length; i++) {
        var node =nodes[i];
        result.push([node, this.mapNodeWithUrl[node]]);
    }

    return result;
};

TrainedModel.prototype.getEdgeArray = function() {
    var result = [];

    var graphIds = Object.keys(this.mapIdToGraph);

    for (var i = 0; i < graphIds.length; i++) {
        var graphId = graphIds[i];
        var graph = this.mapIdToGraph[graphId];
        var parentNodes = Object.keys(graph.links);
        for (var j = 0; j < parentNodes.length; j++) {
            var parentNode = parentNodes[j];
            var childNodesAndWeights = graph.links[parentNode];
            var childNodes = Object.keys(childNodesAndWeights);
            for (var k = 0; k < childNodes.length; k++) {
                var childNode = childNodes[k];
                var weight = childNodesAndWeights[childNode];
                result.push([parentNode, childNode, weight]);
            }
        }
    }

    return result;
};