
function TrainedConnectedGraph() {
    this.links = {}; // represents a Map<ParentNodeId, Map<ChildNodeId, Weight>>; use as this.links[parent][node] = weight
    this.parentsOfNode = {};
    this.linkCount = 0;
}

TrainedConnectedGraph.INITIALIZATION_WEIGHT = 0.1;
TrainedConnectedGraph.EVAPORATE_STRENGTH_PER_GRAPH = 0.01; // Should be less than initialization to prevent instant evaporation if linkCount == 1
TrainedConnectedGraph.FEEDING_STRENGTH_PER_LINK = 0.1;

TrainedConnectedGraph.prototype.addLink = function(parent, child) {
    if (parent === child)
        throw "Both nodes must be different.";

    if (!parent || !child)
        throw "Nodes must have a value.";

    if (!this.links[parent])
        this.links[parent] = {};

    if (!this.parentsOfNode[child])
        this.parentsOfNode[child] = {};

    if (this.links[parent][child])
        return false; // the link already exists, no need to do the adding.

    this.links[parent][child] = TrainedConnectedGraph.INITIALIZATION_WEIGHT;
    this.parentsOfNode[child][parent] = true;

    this.linkCount++;
    return true; // Added the node
};


TrainedConnectedGraph.prototype.removeLink = function(parent, child) {
    if (parent === child)
        throw "Both nodes must be different.";

    if (!parent || !child)
        throw "Nodes must have a value.";

    if (!this.links[parent])
        return false;

    if (!this.parentsOfNode[child])
        return false;

    if (!this.links[parent][child])
        return false; // the link doesn't exists

    delete this.links[parent][child];
    if (Object.keys(this.links[parent]).length <= 0)
        delete this.links[parent];

    delete this.parentsOfNode[child][parent];
    if (Object.keys(this.parentsOfNode[child]).length <= 0)
        delete this.parentsOfNode[child];

    this.linkCount--;
    return true; // Removed the node
};


TrainedConnectedGraph.prototype.addOrFeedLinkBetween = function(parentNode,childNode) {
    if (!this.addLink(parentNode, childNode))
        this.feedLink(parentNode, childNode);
};

TrainedConnectedGraph.prototype.extractLinksFrom = function(otherGraph) {
    for (var parentNode in otherGraph.links) {
        var childrenNodesWithWeight = otherGraph.links[parentNode];

        for (var childNode in childrenNodesWithWeight) {
            var weight = childrenNodesWithWeight[childNode];
            this.addLink(parentNode, childNode)
            this.links[parentNode][childNode] = weight;
        }
    }
};

TrainedConnectedGraph.prototype.feedLink = function(parentNode, node) {
    this.links[parentNode][node] += TrainedConnectedGraph.FEEDING_STRENGTH_PER_LINK;

    // Weight is a percentage, it can never exceed 1.
    if (this.links[parentNode][node] > 1)
        this.links[parentNode][node] = 1;
};

TrainedConnectedGraph.prototype.evaporate = function() {
    var evaporateValue = TrainedConnectedGraph.EVAPORATE_STRENGTH_PER_GRAPH / this.linkCount;
    for (var parentNode in this.links) {
        var childNodesWithWeights = this.links[parentNode];

        for (var childNode in childNodesWithWeights) {
            childNodesWithWeights[childNode]-=evaporateValue;
        }
    }
};

TrainedConnectedGraph.prototype.splitGraphsOnNegativeLinks = function(removedNodes) {
    var removedEdges = [];

    // Find edges that should be removed.
    for (var parentNode in this.links) {
        for (var childNode in this.links[parentNode]) {
            var weight = this.links[parentNode][childNode];
            if (weight < 0) {
                removedEdges.push([parentNode, childNode]);
            }
        }
    }

    // Remove the edges
    for (var i = 0; i < removedEdges.length; i++) {
        var parent = removedEdges[i][0];
        var child = removedEdges[i][1];
        this.removeLink(parent, child);
    }

    var newGraphs = [];

    // Loop over all removedEdges to check whether the removal caused the graph to split in 2 disconnected subgraphs.
    // Extract these disconnected parts from this graph and put them in a new TrainedConnectedGraph instance.
    for (var i = 0; i < removedEdges.length; i++) {
        var parent = removedEdges[i][0];
        var child = removedEdges[i][1];

        if (!this.links[parent] && !this.parentsOfNode[parent]) {
            removedNodes.push(parent);
            continue; // The node no longer belong to this graph, so putting it in another graph is useless.
        }
        if (!this.links[child] && !this.parentsOfNode[child]) {
            removedNodes.push(parent);
            continue; // The node no longer belong to this graph, so putting it in another graph is useless.
        }

        var linkGroup = this.calculateDisconnectedLinkGroup(parent, child);
        if (linkGroup) {
            var newGraph = new TrainedConnectedGraph();
            for (var j = 0; j < linkGroup.length; j++) {
                var lgParent = linkGroup[j][0];
                var lgChild = linkGroup[j][1];
                var lgWeight = this.links[lgParent][lgChild];
                this.removeLink(lgParent, lgChild); // Remove from this graph
                newGraph.addLink(lgParent, lgChild); // Add to the other graph
                newGraph.links[lgParent][lgChild] = lgWeight; // Set the learned weight again
            }
            newGraphs.push(newGraph);
        }
    }

    // Return the new TrainedConnectedGraphs
    return newGraphs;
};

/*
 * Do a bidirectional search to see whether the nodes are connected at some point.
 */
TrainedConnectedGraph.prototype.calculateDisconnectedLinkGroup = function(nodeA, nodeB) {
    var linksVisitedFromA = {};
    var linksVisitedFromB = {};

    var nodesToExpandFromA = [nodeA];
    var nodesToExpandFromB = [nodeB];


    // Keep searching until a tree is completely searched through or a link between both nodes is found.
    while(true) {
        if (nodesToExpandFromA.length <= 0)
            return linksVisitedFromA; // End of tree reached from nodeA -> this is shortest end, return it
        if (nodesToExpandFromB.length <= 0)
            return linksVisitedFromB; // End of tree reached from nodeB -> this is shortest end, return it

        // If search found a connection between the nodes, return false.
        if (this.directionalSearch(linksVisitedFromA, linksVisitedFromB, nodesToExpandFromA))
            return false;

        // If search found a connection between the nodes, return false.
        if (this.directionalSearch(linksVisitedFromB, linksVisitedFromA, nodesToExpandFromB))
            return false;
    }
};

TrainedConnectedGraph.prototype.directionalSearch = function(linksVisited, linksVisitedFromOther, nodesToExpand) {
    var next = nodesToExpand.shift(); // take out the first node in the queue.
    var children = this.links[next]; // Get the children of this node.
    if (!linksVisited[next])
        linksVisited[next] = {};
    if (children) {
        for (var child in children) {
            // If the other direction already found this child, then they're still connected.
            if (linksVisitedFromOther[child])
                return true; // Can't be split in 2.

            if (linksVisited[next] && linksVisited[next][child])
                continue; // Loop found, don't go any further with this one.

            // Add the child to the visited list.
            linksVisited[next][child] = true

            nodesToExpand.push(child); // Let this child be expanded in a next iteration.
        }
    }


    var parents = this.parentsOfNode[next]; // Get the parents of this node.
    if (parents) {
        for (var parent in parents) {
            // If the other direction already found this parent, then they're still connected.
            if (linksVisitedFromOther[parent])
                return true; // Can't be split in 2.

            if (linksVisited[parent] && linksVisited[parent][next])
                continue; // Loop found, don't go any further with this one.

            // Add the child to the visited list.
            if (!linksVisited[parent])
                linksVisited[parent] = {};
            linksVisited[parent][next] = true

            nodesToExpand.push(parent); // Let this parent be expanded in a next iteration.
        }
    }

    return false;
};

TrainedConnectedGraph.prototype.costsFrom = function(node) {
    var result = []; // [][NodeId, cost]

    var nodesToExpand = [node];
    var visited = {};
    visited[node] = 1;
    while(nodesToExpand.length > 0) {
        var previousNode = nodesToExpand.shift(); // Extract first
        var previousNodeCost = visited[previousNode];

        var childrenWithWeight = this.links[previousNode];

        if (!childrenWithWeight)
            continue; // has no children

        for (var child in childrenWithWeight) {

            var weight = childrenWithWeight[child]; // Weight is a probability between 0 and 1
            var cost = previousNodeCost * weight;

            if (child in visited && visited[child] > cost)
                continue; // Child is already found with a higher probability. Ignore to prevent loops.

            nodesToExpand.push(child);
            visited[child] = cost;
        }
    }

    // Convert map to array.
    for (var node in visited) {
        result.push([node, visited[node]]);
    }

    return result;
};

TrainedConnectedGraph.prototype.getNodes = function() {
    var nodes = {};

    for(var parent in this.links) {
        nodes[parent] = true;
        for (var child in this.links[parent]) {
            nodes[child] = true;
        }
    }

    return nodes;
}

TrainedConnectedGraph.prototype.serialize = function() {

    return {
        links: this.links,
        parentsOfNode: this.parentsOfNode,
        linkCount: this.linkCount
    };
};

TrainedConnectedGraph.deserialize = function(data) {
    var tcg = new TrainedConnectedGraph();
    tcg.links = data.links;
    tcg.parentsOfNode = data.parentsOfNode;
    tcg.linkCount = data.linkCount;
    return tcg;
};