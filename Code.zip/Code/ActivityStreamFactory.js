var ActivityStreamFactory = {};

ActivityStreamFactory.MAX_TIME_DIFFERENCE = 1000 * 20; // 20 seconds

ActivityStreamFactory.fileToActivityStreams = function(content) {
    var preprocessed = content.replace(new RegExp("\"| |;|\r", 'g'), "") // Replace all " spaces ; and \r (for windows files)
        .replace(new RegExp(",+", 'g'), ','); // Replace all double comma's
    var lines = preprocessed.split("\n");

    var activityStreams = ActivityStreamFactory.toActivityStreams(lines);

    return activityStreams;

}


ActivityStreamFactory.toActivityStreams = function(lines) {
    var data = [];
    for(var i = 0; i < lines.length; i++) {
        var rawEvent = lines[i].split(",");
        var eventType = rawEvent[1];

        var event = {
            time:new Date(Date.parse(rawEvent[0])),
            action:eventType,
            url: rawEvent[2]
        };

        switch (eventType) {
            case "click": event.target=rawEvent[3]; break;
            case "load": event.top = rawEvent[3]; event.html = rawEvent[4]; break;
            case "polling": break;
            case "beforeunload": break;
        }

        data.push(event);
    }

    return ActivityStreamFactory.toActivityStreamsFromParsedData(data);
};

ActivityStreamFactory.toActivityStreamsFromParsedData = function(data) {
    var activityStreams = [];
    var currentStream = [];
    var currentUrl = null;
    for(var i = 0; i < data.length; i++) {
        var event = data [i];
        if (typeof(event.time) == "string")
            event.time = new Date(Date.parse(event.time));

        if (ActivityStreamFactory.belongsToActivityStream(currentStream, event)) {
            if (event.action == "beforeunload")
                continue; // Before unload messes up our streams, ignore it.
            
            var previousUrl = currentUrl;
            currentUrl = event.url;
            if (currentUrl===previousUrl)
                continue; // Ignore double urls in same stream
            currentStream.push(event);
        }
        else {
            if (currentStream.length >= 2)
                activityStreams.push(currentStream);
            currentStream = [event];

            currentUrl = event.url;
        }
    }

    if (currentStream.length >= 2)
        activityStreams.push(currentStream);

    return activityStreams;
}



ActivityStreamFactory.belongsToActivityStream = function(activityStream, event) {
    if (activityStream.length < 1) return true;

    var last = activityStream[activityStream.length-1];

    var timeDifference = Math.abs(event.time - last.time);
    if (timeDifference > 0 && timeDifference < ActivityStreamFactory.MAX_TIME_DIFFERENCE ) {
        return true;
    }

    return false;
}

ActivityStreamFactory.trainModel = function(model, activityStreams) {
    model.trainFromActivityStreams(activityStreams);
}