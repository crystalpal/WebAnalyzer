
var Node = function(url){
    //this.uid = Node.nextUid++;
    //this.url = url;
};
Node.nextUid = 0;
Node.prototype.getTrainedConnectedGraph = function() {
    return this.trainedConnectedGraph;
}

Node.prototype.setTrainedConnectedGraph = function(graph) {
    this.trainedConnectedGraph = graph;
}