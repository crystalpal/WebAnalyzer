// ==UserScript==
// @name        ML Project
// @namespace   be.kuleuven.cs.dtai
// @description Show most likely next links
// @version     1
// @grant       GM_xmlhttpRequest
// @grant       GM_setValue
// @grant       GM_getValue
// @grant       GM_addStyle
// @grant       GM_getResourceText
// @run-at      document-start
// @match       *://*/*
// @require     http://code.jquery.com/jquery-latest.js
// @require     http://localhost/Code/RealTimeDataCollector.js
// @require     http://localhost/Code/ActivityStreamFactory.js
// @require     http://localhost/Code/Node.js
// @require     http://localhost/Code/TrainedConnectedGraph.js
// @require     http://localhost/Code/TrainedModel.js
// @require     http://localhost/Code/GUI.js
// @require     http://js.cytoscape.org/js/cytoscape.min.js
// @require     https://cdn.rawgit.com/cytoscape/cytoscape.js-cose-bilkent/1.0.2/cytoscape-cose-bilkent.js
// @require     http://localhost/Code/main.js
// @resource    GUI_CSS http://localhost/Code/gui.css
// @noframes
// ==/UserScript==

if (Main) {

    var css = GM_getResourceText ("GUI_CSS");

    GM_addStyle (css);

    console.log("Main.js loaded");
}