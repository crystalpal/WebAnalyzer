

var Main = {};
Main.realTimeLearning = true;

Main.findProposals = function(url) {
    console.log("Querying url: " + url);
    var matches = Main.model.selectBestMatches(url, 5);
    console.log(matches);
    return matches;
};

Main.loadModelData = function() {
    // Prepare stored model
    var modelData= typeof(GM_getValue) != "undefined" ? GM_getValue("trainedmodel") : localStorage.getItem("trainedmodel");
    Main.model = new TrainedModel();
    if (modelData)
        Main.model = TrainedModel.deserialize(JSON.parse(modelData));
};

Main.onFileRead = function(e) {
    // Train with new data
    var contents = e.target.result;
    var activityStreams = ActivityStreamFactory.fileToActivityStreams(contents);
    ActivityStreamFactory.trainModel(Main.model, activityStreams);

    Main.saveModel();

    alert("Model trained and saved successfully");
    document.getElementById("inputCSVFile").value = null;
};

Main.saveModel = function() {
    // Store model
    if ( typeof(GM_setValue) != "undefined")
        GM_setValue("trainedmodel", JSON.stringify(Main.model.serialize()));
    else localStorage.setItem("trainedmodel", JSON.stringify(Main.model.serialize()));
};


Main.readSingleFile = function(e) {
    var file = e.target.files[0];
    if (!file) {
        return;
    }
    var reader = new FileReader();
    reader.onload = Main.onFileRead;
    reader.readAsText(file);
};


Main.testLinks = [
    "http://www.google.be",
    "http://www.facebook.com"
];

Main.tryLearnNewCollectedStream = function() {
    var browsingStream = RealTimeDataCollector.getCollectedBrowsingStream();
    var activityStreams = ActivityStreamFactory.toActivityStreamsFromParsedData(browsingStream);

    console.log("streams so far");
    console.log(activityStreams);
    if (activityStreams.length < 2) // We want at least 2 streams, because the last one might be incomplete and should be set aside for later.
        return;

    var streamsToLearn = activityStreams.slice(0,-1); // Don't learn last stream, because it might be incomplete.
    var streamToStore = activityStreams[activityStreams.length - 1]; // Store last stream again, so it can grow further.

    console.log("Learning new streams:");
    console.log(streamsToLearn);


    ActivityStreamFactory.trainModel(Main.model, streamsToLearn);
    RealTimeDataCollector.setCollectedBrowsingStream(streamToStore);

    Main.saveModel();
};

window.addEventListener("load", function() {

    Main.loadModelData();
    if (Main.realTimeLearning) {
        RealTimeDataCollector.collectRealTimeData();
        Main.tryLearnNewCollectedStream();
    }
    console.log(JSON.stringify(RealTimeDataCollector.getCollectedBrowsingStream()));
    GUI.createGUI();

    var matches = Main.findProposals(window.location.href);

    if (matches && matches.length > 0) {
        GUI.proposeLinks(matches);
        GUI.showProposedLinks();
    }

    console.log("Script is succesvol uitgevoerd ;)");
});
