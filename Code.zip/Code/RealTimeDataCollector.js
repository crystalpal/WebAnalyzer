/**
 * Handles collecting real time data to learn.
 * Generally sort of does the same as the provided
 * URL Stream Handler, but in stead of sending it
 * to a server, it stores it locally.
 */
var RealTimeDataCollector = {};

RealTimeDataCollector.saveBrowsingStreamItem = function(activityStreamItem) {

    activityStreamItem.time = new Date().toISOString();

    var currentActivityStream = RealTimeDataCollector.getCollectedBrowsingStream();

    currentActivityStream.push(activityStreamItem);
    console.log("New browsing item added:");
    console.log(activityStreamItem);

    RealTimeDataCollector.setCollectedBrowsingStream(currentActivityStream);

};

RealTimeDataCollector.getCollectedBrowsingStream = function() {
    var currentActivityStream = typeof(GM_getValue) != "undefined" ? GM_getValue("activitystream") : localStorage.getItem("activitystream");
    if (!currentActivityStream)
        currentActivityStream = [];
    else currentActivityStream = JSON.parse(currentActivityStream);

    return currentActivityStream;
};

RealTimeDataCollector.setCollectedBrowsingStream = function(stream) {

    if ( typeof(GM_setValue) != "undefined")
        GM_setValue("activitystream", JSON.stringify(stream));
    else localStorage.setItem("activitystream", JSON.stringify(stream));

};


RealTimeDataCollector.collectRealTimeData = function() {
    var toppage = (window.top == window.self);
    if (!toppage) {
        return;
    }
    // Associate a click event with all links
    var addClickEvent = function(element) {
        if (element.dataset.dtaitracked) {
            return;
        }
        element.dataset.dtaitracked = true;
        element.addEventListener('click', function(link) {return function(event) {
            try {
                var href = '';
                if (link.href !== undefined) {
                    href = link.href;
                }
                var activityStreamItem = {
                    "action": "click",
                    "target": href,
                    "url": window.location.href
                };
                RealTimeDataCollector.saveBrowsingStreamItem(activityStreamItem);
            } catch (e) {
                console.log('An error occured in a click listener', e);
            }
        };}(element));
    };
    for (var i=0; i<document.links.length; i++) {
        addClickEvent(document.links[i]);
    }

    // Window events
    // Possible events include hashchange, pageshow, popstate, beforeunload
    window.addEventListener('beforeunload', function(event) {
        RealTimeDataCollector.saveBrowsingStreamItem({
            "action": 'beforeunload',
            "url": window.location.href
        });
    });

    // Send current page load and react to result
    var html = '';
    if (document.body) {
        html = document.body.innerHTML;
    }
    RealTimeDataCollector.saveBrowsingStreamItem({
        "action": "load",
        "url": window.location.href,
        "top": "", //toppage,
        "html": "", //html,
    });
};
