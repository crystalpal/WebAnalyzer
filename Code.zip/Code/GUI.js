GUI = {};
GUI.proposeLinks = function(links) {
    if (!links) {
        GUI.divProposeLinks.getElementsByTagName("h3")[0].innerHTML = "Nothing to predict for this page yet :(";
        return;
    }
    GUI.olProposedLinks.innerHTML = "";
    for(var i = 0; i < links.length; i++) {
        console.log("Appending " + links[i]);
        GUI.olProposedLinks.innerHTML += "<li><a href='" + links[i] + "'>" + links[i] + "</a></li>";
    }
    GUI.divProposeLinks.getElementsByTagName("h3")[0].innerHTML = "Are you looking for one of these pages?";
};

GUI.createGUI = function() {
    // create propose links area
    GUI.divProposeLinks = document.createElement("div");
    GUI.divProposeLinks.id="divProposeLinks";
    GUI.divProposeLinks.innerHTML = "<h3>Nothing to predict for this page yet :(</h3>";
    GUI.hideProposedLinks();//Hide on create
    var body = document.getElementsByTagName("body")[0];
    body.appendChild(GUI.divProposeLinks);

    GUI.olProposedLinks = document.createElement("ol");
    GUI.olProposedLinks.id = "olProposedLinks";
    GUI.divProposeLinks.appendChild(GUI.olProposedLinks);
    var mouseMoveListener = function() {
        var right = Number.parseInt(window.getComputedStyle(GUI.divProposeLinks).right.replace("px", ""));
        if (right < -300)
            GUI.divProposeLinks.classList.remove("hidden");
    };
    GUI.divProposeLinks.addEventListener("mousemove", mouseMoveListener);

    var btnOpenSettings = document.createElement("button");
    btnOpenSettings.id = "btnOpenSettings";
    btnOpenSettings.innerHTML= "Settings";
    btnOpenSettings.onclick = function(){ GUI.showSettings()};
    GUI.divProposeLinks.appendChild(btnOpenSettings);

    var btnHideProposals = document.createElement("button");
    btnHideProposals.id = "btnHideProposals";
    btnHideProposals.innerHTML= "Hide this";
    btnHideProposals.onclick = function(){ GUI.hideProposedLinks()};
    GUI.divProposeLinks.appendChild(btnHideProposals);

    // create settings area
    GUI.divSettings = document.createElement("div");
    GUI.divSettings.id="divSettings";
    GUI.divSettings.onclick=function() { console.log("hiding settings"); GUI.hideSettings(); }
    GUI.hideSettings();//Hide on create
    body.appendChild(GUI.divSettings);

    var subDivSettings = document.createElement("div");
    subDivSettings.onclick=function(e) {e.stopPropagation(); }
    GUI.divSettings.appendChild(subDivSettings);

    var labelCSVFile = document.createElement("label");
    labelCSVFile.id = "labelCSVFile";
    labelCSVFile.innerHTML = "Load CSV file:";
    subDivSettings.appendChild(labelCSVFile);

    var inputCSVFile = document.createElement("input");
    inputCSVFile.type = "file";
    inputCSVFile.id = "inputCSVFile";
    inputCSVFile.addEventListener('change', Main.readSingleFile, false);
    subDivSettings.appendChild(inputCSVFile);

    var inputUrl = document.createElement("input");
    inputUrl.type = "text";
    inputUrl.id = "inputUrl";
    inputUrl.placeholder="The input url";
    inputUrl.value = "https://www.facebook.com/";
    subDivSettings.appendChild(inputUrl);

    var btnFindProposals = document.createElement("button");
    btnFindProposals.innerHTML = "Find proposals";
    btnFindProposals.id = "btnFindProposals";
    btnFindProposals.onclick = function() { Main.findProposals(document.getElementById("inputUrl").value)} ;
    subDivSettings.appendChild(btnFindProposals);

    var btnShowGraph = document.createElement("button");
    btnShowGraph.innerHTML = "Show graph";
    btnShowGraph.id = "btnShowGraph";
    btnShowGraph.onclick = function() {
        GUI.hideSettings();
        GUI.showGraph();
        console.log("start drawing graph...");
        GUI.drawGraph(Main.model.getNodeArray(), Main.model.getEdgeArray());
        console.log("drawing graph finished");
    } ;
    subDivSettings.appendChild(btnShowGraph);

    var btnClearModel = document.createElement("button");
    btnClearModel.innerHTML = "Clear model data";
    btnClearModel.id = "btnClearModel";
    btnClearModel.onclick = function() {
        localStorage.removeItem("trainedmodel");
        if (typeof(GM_setValue) != "undefined") {
            GM_setValue("trainedmodel", "");
            //GM_deleteValue("trainedmodel"); // Not sure whether this works
            console.log("GM_deleteValue executed");
        }

        Main.loadModelData();
    } ;
    subDivSettings.appendChild(btnClearModel);

    var btnClearActivityStreams = document.createElement("button");
    btnClearActivityStreams.innerHTML = "Clear collected activity streams";
    btnClearActivityStreams.id = "btnClearActivityStreams";
    btnClearActivityStreams.onclick = function() {
        localStorage.removeItem("activitystream");
        if (typeof(GM_setValue) != "undefined") {
            GM_setValue("activitystream", "");
            //GM_deleteValue("activitystream"); // Not sure whether this works
            console.log("GM_deleteValue executed");
        }
    } ;
    subDivSettings.appendChild(btnClearActivityStreams);


    // create graph area
    GUI.divGraph = document.createElement("div");
    GUI.divGraph.id="divGraph";
    GUI.divGraph.onclick=function() { console.log("hiding graph"); GUI.hideGraph(); }
    GUI.hideGraph();//Hide on create
    body.appendChild(GUI.divGraph);

    var divCy = document.createElement("div");
    divCy.addEventListener("click",function(e) {e.stopPropagation(); });
    divCy.id = "cy";
    GUI.divGraph.appendChild(divCy);
};


GUI.showProposedLinks = function() {
    GUI.divProposeLinks.classList.remove("hidden");
};

GUI.hideProposedLinks = function() {
    GUI.divProposeLinks.classList.add("hidden");
};

GUI.showSettings = function() {
    GUI.hideGraph();
    GUI.divSettings.classList.remove("hidden");
};

GUI.hideSettings = function() {
    GUI.divSettings.classList.add("hidden");
};

GUI.showGraph = function() {
    GUI.hideSettings();
    GUI.divGraph.classList.remove("hidden");
};

GUI.hideGraph = function() {
    GUI.divGraph.classList.add("hidden");
};

GUI.drawGraph = function(nodesWithName, edgesWithWeight) {
    var nodes = [];
    var edges = [];

    for(var i = 0; i < nodesWithName.length; i++) {
        nodes.push({
            data: {
                id:nodesWithName[i][0],
                name:nodesWithName[i][1]
            }
        })
    }

    for(var i = 0; i < edgesWithWeight.length; i++) {
        edges.push({
            data: {
                source: edgesWithWeight[i][0],
                target: edgesWithWeight[i][1],
                label: edgesWithWeight[i][2]
            }
        })
    }

    console.log("nodes");
    console.log(nodes);
    console.log("edges");
    console.log(edges);
    var cy = window.cy = cytoscape({

        container: document.querySelector('#cy'),

        boxSelectionEnabled: false,
        autounselectify: true,

        style: cytoscape.stylesheet()
            .selector('node')
            .css({
                'content': 'data(name)',
                'text-valign': 'center',
                'color': 'white',
                'text-outline-width': 2,
                'text-outline-color': '#888'
            })
            .selector('edge')
            .css({
                'target-arrow-shape': 'triangle',
                'label': 'data(label)'
            })
            .selector(':selected')
            .css({
                'background-color': 'black',
                'line-color': 'black',
                'target-arrow-color': 'black',
                'source-arrow-color': 'black'
            })
            .selector('.faded')
            .css({
                'opacity': 0.25,
                'text-opacity': 0
            }),


        elements: {
            nodes: nodes,
            edges: edges
        },


        layout: {
            name: 'cose-bilkent'
        }
    });

    cy.on('tap', 'node', function(e){
        var node = e.cyTarget;
        var neighborhood = node.neighborhood().add(node);

        cy.elements().addClass('faded');
        neighborhood.removeClass('faded');
    });

    cy.on('tap', function(e){
        if( e.cyTarget === cy ){
            cy.elements().removeClass('faded');
        }
    });

}